let flowChart = null;

function fmt(value, digits=2) {
  const n = Number(value);
  return Number.isFinite(n) ? n.toFixed(digits) : "--";
}
function setText(id, value) {
  const el = document.getElementById(id);
  if (el) el.textContent = value;
}
function setStatusBadge(status) {
  const badge = document.getElementById("connectionBadge");
  if (!badge) return;
  badge.className = "status-chip";
  if (status === "OFFLINE") badge.classList.add("offline");
  if (status === "LEAKAGE") badge.classList.add("leak");
  badge.innerHTML = '<span class="dot"></span>' + (status === "OFFLINE" ? "Device offline" : status === "LEAKAGE" ? "Possible leakage" : "Device connected");
}
function updateChart(data) {
  const canvas = document.getElementById("flowChart");
  if (!canvas || typeof Chart === "undefined") return;
  const config = {
    type: "line",
    data: {
      labels: data.labels || [],
      datasets: [
        {label:"Inlet flow", data:data.flow1_series || [], borderColor:"#287fd0", backgroundColor:"rgba(40,127,208,.08)", tension:.35, fill:true, pointRadius:2},
        {label:"Outlet flow", data:data.flow2_series || [], borderColor:"#20a6bd", backgroundColor:"rgba(32,166,189,.04)", tension:.35, fill:false, pointRadius:2}
      ]
    },
    options: {responsive:true, plugins:{legend:{labels:{boxWidth:8,usePointStyle:true,font:{size:10}}}}, scales:{x:{grid:{display:false},ticks:{font:{size:9},maxTicksLimit:8}},y:{beginAtZero:true,grid:{color:"#edf1f5"},ticks:{font:{size:9}}}}}
  };
  if (!flowChart) flowChart = new Chart(canvas, config);
  else {
    flowChart.data = config.data;
    flowChart.update("none");
  }
}
async function refreshStatus() {
  if (!document.getElementById("flow1") && !document.getElementById("pipelineStatus")) return;
  try {
    const response = await fetch("/api/status", {cache:"no-store"});
    if (!response.ok) return;
    const d = await response.json();
    setText("flow1", fmt(d.flow1));
    setText("flow2", fmt(d.flow2));
    setText("loss", fmt(d.loss_lpm));
    setText("lossPct", fmt(d.loss_percent) + "%");
    setText("pipelineStatus", d.pipeline_status);
    setText("lastSeen", d.last_seen ? "Last reading: " + d.last_seen.replace("T"," ") : "No readings received yet");
    setText("connectionText", d.connected ? "Connected" : "Offline");
    setText("connectionBadge", d.connected ? "Device connected" : "Device offline");
    setStatusBadge(d.pipeline_status);
    const pv = document.querySelector(".pipeline-visual");
    if (pv) pv.classList.toggle("leaking", !!d.leak);
    setText("pipelineNote", d.leak ? "Possible flow loss detected between the two sensors." : d.connected ? "No leakage condition detected by the configured rule." : "Waiting for live sensor readings.");
    setText("relayState", d.leak ? "ON · leakage rule" : d.connected ? "OFF · normal" : "Waiting");
    setText("valveStatus", d.leak ? "Relay ON – possible leakage" : d.connected ? "Relay OFF – normal condition" : "Waiting for device data");
    setText("valveConnection", d.connected ? "Device connected" : "Device offline");
    setText("loss", fmt(d.loss_lpm) + " L/min");
    updateChart(d);
  } catch (e) {
    console.warn("Could not refresh dashboard:", e);
  }
}
async function loadAlerts() {
  const recent = document.getElementById("recentAlerts");
  const table = document.getElementById("alertsTable");
  if (!recent && !table) return;
  try {
    const r = await fetch("/api/alerts");
    const rows = await r.json();
    if (recent) recent.innerHTML = rows.length ? rows.slice(0,4).map(x => `<div class="alert-item"><b>⚑ ${escapeHtml(x.message)}</b><small>${escapeHtml(x.created_at)}</small></div>`).join("") : '<div class="empty-state">No alerts recorded yet.</div>';
    if (table) table.innerHTML = rows.length ? rows.map(x => `<tr><td><span class="badge bad">Possible leakage</span></td><td>${escapeHtml(x.message)}</td><td>${escapeHtml(x.created_at)}</td></tr>`).join("") : '<tr><td colspan="3" class="empty-state">No alerts recorded yet.</td></tr>';
  } catch(e) { console.warn(e); }
}
async function loadHistory() {
  const table = document.getElementById("historyTable");
  if (!table) return;
  try {
    const r = await fetch("/api/history");
    const rows = await r.json();
    table.innerHTML = rows.length ? rows.map(x => `<tr><td>${escapeHtml(x.created_at)}</td><td>${fmt(x.flow1)}</td><td>${fmt(x.flow2)}</td><td><span class="badge ${x.leak_detected ? "bad" : ""}">${x.leak_detected ? "LEAKAGE" : "NORMAL"}</span></td></tr>`).join("") : '<tr><td colspan="4" class="empty-state">No readings received yet.</td></tr>';
  } catch(e) { console.warn(e); }
}
function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}
document.addEventListener("DOMContentLoaded", () => {
  refreshStatus(); loadAlerts(); loadHistory();
  setInterval(refreshStatus, 3000);
  setInterval(loadAlerts, 10000);
  setInterval(loadHistory, 10000);
});
