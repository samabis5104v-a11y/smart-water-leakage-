import os
import sqlite3
from datetime import datetime, timezone
from functools import wraps

from flask import Flask, render_template, request, redirect, url_for, session, jsonify, flash
from werkzeug.security import generate_password_hash, check_password_hash

APP_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(APP_DIR, "database.db")
app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", "change-this-secret-before-deployment")
DEVICE_API_KEY = os.environ.get("DEVICE_API_KEY", "change-this-device-key")
LEAK_DIFFERENCE_LPM = float(os.environ.get("LEAK_DIFFERENCE_LPM", "2.0"))
LEAK_MIN_INLET_LPM = float(os.environ.get("LEAK_MIN_INLET_LPM", "1.0"))


def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL CHECK(role IN ('admin','user'))
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS readings (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                flow1 REAL NOT NULL,
                flow2 REAL NOT NULL,
                leak_detected INTEGER NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS alerts (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                message TEXT NOT NULL,
                created_at TEXT NOT NULL
            )
        """)
        count = conn.execute("SELECT COUNT(*) AS n FROM users").fetchone()["n"]
        if count == 0:
            conn.execute(
                "INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",
                ("admin", generate_password_hash("Admin@123"), "admin")
            )
            conn.execute(
                "INSERT INTO users(username,password_hash,role) VALUES(?,?,?)",
                ("user", generate_password_hash("User@123"), "user")
            )


def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        return fn(*args, **kwargs)
    return wrapper


def admin_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if "user_id" not in session:
            return redirect(url_for("login"))
        if session.get("role") != "admin":
            flash("Admin access is required for that action.", "error")
            return redirect(url_for("dashboard"))
        return fn(*args, **kwargs)
    return wrapper


@app.route("/")
def index():
    if "user_id" in session:
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))


@app.route("/login", methods=["GET", "POST"])
def login():
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        password = request.form.get("password", "")
        with db() as conn:
            user = conn.execute("SELECT * FROM users WHERE username=?", (username,)).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.update(user_id=user["id"], username=user["username"], role=user["role"])
            return redirect(url_for("dashboard"))
        flash("Incorrect username or password.", "error")
    return render_template("login.html")


@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))


@app.route("/dashboard")
@login_required
def dashboard():
    return render_template("dashboard.html")


@app.route("/sensors")
@login_required
def sensors():
    return render_template("sensors.html")


@app.route("/alerts")
@login_required
def alerts():
    return render_template("alerts.html")


@app.route("/history")
@login_required
def history():
    return render_template("history.html")


@app.route("/valves")
@login_required
def valves():
    return render_template("valves.html")


@app.route("/settings", methods=["GET", "POST"])
@admin_required
def settings():
    global LEAK_DIFFERENCE_LPM, LEAK_MIN_INLET_LPM
    if request.method == "POST":
        try:
            LEAK_DIFFERENCE_LPM = max(0.1, float(request.form["difference"]))
            LEAK_MIN_INLET_LPM = max(0.0, float(request.form["minimum"]))
            flash("Detection thresholds updated for this server session.", "success")
        except (ValueError, KeyError):
            flash("Enter valid numeric thresholds.", "error")
    return render_template("settings.html",
                           difference=LEAK_DIFFERENCE_LPM,
                           minimum=LEAK_MIN_INLET_LPM)


def calculate_leak(flow1, flow2):
    # Basic demonstration rule; calibrate and validate with real pipe tests.
    return flow1 >= LEAK_MIN_INLET_LPM and (flow1 - flow2) >= LEAK_DIFFERENCE_LPM


@app.route("/api/readings", methods=["POST"])
def receive_readings():
    supplied_key = request.headers.get("X-API-Key", "")
    if supplied_key != DEVICE_API_KEY:
        return jsonify({"ok": False, "error": "Unauthorized device"}), 401
    data = request.get_json(silent=True) or {}
    try:
        flow1 = float(data["flow1"])
        flow2 = float(data["flow2"])
        if not (0 <= flow1 <= 10000 and 0 <= flow2 <= 10000):
            raise ValueError("Flow readings outside allowed range")
    except (KeyError, TypeError, ValueError):
        return jsonify({"ok": False, "error": "Expected numeric flow1 and flow2 values"}), 400

    leak = calculate_leak(flow1, flow2)
    now = datetime.now(timezone.utc).astimezone().isoformat(timespec="seconds")
    with db() as conn:
        conn.execute(
            "INSERT INTO readings(flow1,flow2,leak_detected,created_at) VALUES(?,?,?,?)",
            (flow1, flow2, int(leak), now)
        )
        if leak:
            previous = conn.execute(
                "SELECT leak_detected FROM readings ORDER BY id DESC LIMIT 1 OFFSET 1"
            ).fetchone()
            if not previous or not previous["leak_detected"]:
                conn.execute(
                    "INSERT INTO alerts(message,created_at) VALUES(?,?)",
                    (f"Possible leakage: inlet {flow1:.2f} L/min, outlet {flow2:.2f} L/min", now)
                )
    return jsonify({"ok": True, "leak_detected": leak, "created_at": now})


@app.route("/api/status")
@login_required
def api_status():
    with db() as conn:
        latest = conn.execute("SELECT * FROM readings ORDER BY id DESC LIMIT 1").fetchone()
        total = conn.execute("""
            SELECT COUNT(*) AS readings,
                   COALESCE(SUM(leak_detected),0) AS leak_samples
            FROM readings
        """).fetchone()
        alert_count = conn.execute("SELECT COUNT(*) AS n FROM alerts").fetchone()["n"]
        recent = conn.execute("SELECT * FROM readings ORDER BY id DESC LIMIT 30").fetchall()
    if latest:
        age = (datetime.now(timezone.utc) - datetime.fromisoformat(latest["created_at"]).astimezone(timezone.utc)).total_seconds()
        connected = age < 20
        f1, f2, leak = latest["flow1"], latest["flow2"], bool(latest["leak_detected"])
        stamp = latest["created_at"]
    else:
        connected, f1, f2, leak, stamp = False, 0, 0, False, None
    loss = max(0, f1 - f2)
    loss_pct = (loss / f1 * 100) if f1 > 0 else 0
    return jsonify({
        "connected": connected, "flow1": f1, "flow2": f2,
        "loss_lpm": loss, "loss_percent": loss_pct,
        "leak": leak, "pipeline_status": "LEAKAGE" if leak else ("NORMAL" if connected else "OFFLINE"),
        "last_seen": stamp, "alert_count": alert_count,
        "labels": [r["created_at"][11:19] for r in reversed(recent)],
        "flow1_series": [r["flow1"] for r in reversed(recent)],
        "flow2_series": [r["flow2"] for r in reversed(recent)]
    })


@app.route("/api/alerts")
@login_required
def api_alerts():
    with db() as conn:
        rows = conn.execute("SELECT * FROM alerts ORDER BY id DESC LIMIT 100").fetchall()
    return jsonify([dict(r) for r in rows])


@app.route("/api/history")
@login_required
def api_history():
    with db() as conn:
        rows = conn.execute("SELECT * FROM readings ORDER BY id DESC LIMIT 200").fetchall()
    return jsonify([dict(r) for r in rows])


@app.route("/api/device-config")
def device_config():
    if request.headers.get("X-API-Key", "") != DEVICE_API_KEY:
        return jsonify({"ok": False}), 401
    return jsonify({
        "leak_difference_lpm": LEAK_DIFFERENCE_LPM,
        "leak_min_inlet_lpm": LEAK_MIN_INLET_LPM
    })


@app.route("/health")
def health():
    return jsonify({"ok": True})


if __name__ == "__main__":
    init_db()
    # Host 0.0.0.0 allows ESP32 on the same Wi-Fi network to reach this PC.
    app.run(host="0.0.0.0", port=5000, debug=False)
