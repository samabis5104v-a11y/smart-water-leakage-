SMART WATER LEAKAGE MANAGEMENT & ALERT SYSTEM
==============================================

A. SOFTWARE REQUIREMENTS
- Windows 10/11
- Python 3.10 or newer
- VS Code
- ESP32 with MicroPython firmware
- ESP32 and the computer must be on the same Wi-Fi network

B. RUN THE WEBSITE
1. Extract this ZIP.
2. Open the extracted smart_water_leakage_project folder in VS Code.
3. Open VS Code Terminal: Terminal > New Terminal.
4. Create a virtual environment:
      py -m venv .venv
5. Activate it in PowerShell:
      .\.venv\Scripts\Activate.ps1
   If PowerShell blocks activation, use Command Prompt:
      .venv\Scripts\activate.bat
6. Install packages:
      py -m pip install -r requirements.txt
7. Run:
      py app.py
8. Open this on your PC:
      http://127.0.0.1:5000

C. FIRST LOGIN
Admin: admin
Password: Admin@123

User: user
Password: User@123

Change these demo passwords before using this system outside a classroom/demo network.
The starter application uses a simple session-based login. Add stronger account management,
HTTPS, CSRF protection, and secure secret management before any public deployment.

D. CONNECT ESP32
1. In esp32/main.py, set your Wi-Fi SSID and password.
2. Find your computer's local IPv4 address:
      ipconfig
   Find the IPv4 Address of the Wi-Fi adapter, e.g. 192.168.1.10.
3. In esp32/main.py, set:
      SERVER_URL = "http://192.168.1.10:5000/api/readings"
   Replace the example IP with your computer's actual LAN IPv4 address.
4. Set DEVICE_API_KEY to the same value as the Flask DEVICE_API_KEY.
   The default demo value is "change-this-device-key".
5. Make sure Windows Firewall allows Python on private networks and that both devices
   are connected to the same Wi-Fi.
6. Upload esp32/main.py to the ESP32 as main.py using Thonny or another MicroPython tool.
7. Restart the ESP32. The dashboard should show live values when sensor data arrives.

E. IMPORTANT HARDWARE NOTES
- The website receives flow1 and flow2 in litres per minute.
- The initial leakage rule is: inlet >= minimum inlet AND inlet - outlet >= difference.
- This is only a basic demonstration rule. A difference can also be caused by sensor
  calibration error, air, turbulence, restrictions, or timing mismatch.
- Calibrate both flow sensors against a measured volume and tune the threshold before
  relying on leakage decisions.
- The ESP32 performs the relay action locally. The website does not remotely switch
  the relay in this starter version.
- Test the relay with the valve disconnected. Confirm whether the relay module is
  active-HIGH or active-LOW and set RELAY_ACTIVE_LEVEL accordingly.
- Never power a motorized valve directly from an ESP32 GPIO. Use a correctly rated
  driver/relay, separate supply, and appropriate electrical protection.
- Use a suitable power supply and common ground where required. Ensure flow sensor
  signal voltage never exceeds the ESP32's 3.3V GPIO limit.

F. DATA STORAGE
- database.db is created automatically the first time app.py runs.
- It stores user accounts, sensor readings, and leakage alerts.
- Back up database.db before deleting or resetting the project.

G. DEMO MODE
This starter project does not invent sensor values. Without an ESP32 sending readings,
the dashboard correctly shows the device as offline. For a classroom demo without
hardware, add a clearly labelled simulator rather than treating simulated values as
real hardware readings.
