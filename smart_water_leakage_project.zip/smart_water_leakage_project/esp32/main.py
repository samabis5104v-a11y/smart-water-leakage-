# Smart Water Leakage Management & Alert System
# MicroPython code for ESP32 DevKit V1
#
# Wiring:
# Flow sensor 1 signal -> GPIO25
# Flow sensor 2 signal -> GPIO26
# Relay IN             -> GPIO5
# LED (through resistor) -> GPIO12
#
# IMPORTANT:
# 1. Set WIFI_SSID, WIFI_PASSWORD, SERVER_URL and DEVICE_API_KEY.
# 2. SERVER_URL must use your computer's LAN IPv4 address, e.g.
#    http://192.168.1.10:5000/api/readings (NOT localhost).
# 3. Make sure PC and ESP32 are on the same Wi-Fi.
# 4. Test relay logic with the valve disconnected first.

import network
import machine
import micropython
import time
import ujson
import urequests
from machine import Pin

WIFI_SSID = "YOUR_WIFI_NAME"
WIFI_PASSWORD = "YOUR_WIFI_PASSWORD"

SERVER_URL = "http://192.168.1.10:5000/api/readings"
DEVICE_API_KEY = "change-this-device-key"

SENSOR1_PIN = 25
SENSOR2_PIN = 26
RELAY_PIN = 5
LED_PIN = 12

# The original Arduino sketch used calibration factor 6.
# Confirm this experimentally with your exact YF-S201 sensor.
CALIBRATION_FACTOR_1 = 6.0
CALIBRATION_FACTOR_2 = 6.0

# Match these values with the Flask settings.
LEAK_DIFFERENCE_LPM = 2.0
LEAK_MIN_INLET_LPM = 1.0

# Change to 0 if your relay board is active-LOW.
RELAY_ACTIVE_LEVEL = 1

pulse_count_1 = 0
pulse_count_2 = 0

sensor1 = Pin(SENSOR1_PIN, Pin.IN, Pin.PULL_UP)
sensor2 = Pin(SENSOR2_PIN, Pin.IN, Pin.PULL_UP)
relay = Pin(RELAY_PIN, Pin.OUT)
led = Pin(LED_PIN, Pin.OUT)

relay.value(1 - RELAY_ACTIVE_LEVEL)  # Start relay OFF
led.value(0)

def sensor1_irq(pin):
    global pulse_count_1
    pulse_count_1 += 1

def sensor2_irq(pin):
    global pulse_count_2
    pulse_count_2 += 1

sensor1.irq(trigger=Pin.IRQ_FALLING, handler=sensor1_irq)
sensor2.irq(trigger=Pin.IRQ_FALLING, handler=sensor2_irq)

def connect_wifi():
    wlan = network.WLAN(network.STA_IF)
    wlan.active(True)
    if not wlan.isconnected():
        print("Connecting to Wi-Fi...")
        wlan.connect(WIFI_SSID, WIFI_PASSWORD)
        timeout = 25
        while not wlan.isconnected() and timeout > 0:
            time.sleep(1)
            timeout -= 1
    if wlan.isconnected():
        print("Wi-Fi connected:", wlan.ifconfig())
        return wlan
    print("Wi-Fi connection failed")
    return wlan

def set_relay(on):
    relay.value(RELAY_ACTIVE_LEVEL if on else 1 - RELAY_ACTIVE_LEVEL)
    led.value(1 if on else 0)

def send_to_server(flow1, flow2):
    payload = {
        "flow1": round(flow1, 2),
        "flow2": round(flow2, 2)
    }
    headers = {
        "Content-Type": "application/json",
        "X-API-Key": DEVICE_API_KEY
    }
    response = None
    try:
        response = urequests.post(
            SERVER_URL,
            data=ujson.dumps(payload),
            headers=headers
        )
        print("Server response:", response.status_code, response.text)
        return response.status_code == 200
    except Exception as error:
        print("HTTP error:", error)
        return False
    finally:
        if response is not None:
            response.close()

wlan = connect_wifi()
last_sample = time.ticks_ms()

while True:
    now = time.ticks_ms()
    elapsed_ms = time.ticks_diff(now, last_sample)

    if elapsed_ms >= 1000:
        # Briefly disable interrupts while copying/resetting pulse counts.
        irq_state = machine.disable_irq()
        p1 = pulse_count_1
        p2 = pulse_count_2
        pulse_count_1 = 0
        pulse_count_2 = 0
        machine.enable_irq(irq_state)

        # Preserve the calculation used in the supplied Arduino sketch:
        # flow rate = (pulses per second) / calibration factor.
        # The resulting unit/calibration must be verified with your sensor
        # and a measured volume before relying on the displayed L/min value.
        flow1 = ((p1 * 1000.0 / elapsed_ms) / CALIBRATION_FACTOR_1)
        flow2 = ((p2 * 1000.0 / elapsed_ms) / CALIBRATION_FACTOR_2)

        leak = (
            flow1 >= LEAK_MIN_INLET_LPM and
            (flow1 - flow2) >= LEAK_DIFFERENCE_LPM
        )

        set_relay(leak)

        print("--------------------------------")
        print("Inlet flow :", round(flow1, 2), "L/min")
        print("Outlet flow:", round(flow2, 2), "L/min")
        print("Status     :", "LEAKAGE" if leak else "NORMAL")

        if not wlan.isconnected():
            wlan = connect_wifi()

        if wlan.isconnected():
            send_to_server(flow1, flow2)

        last_sample = now

    time.sleep_ms(10)
